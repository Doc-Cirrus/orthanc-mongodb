This file contains a precompiled version of several open-source fonts,
that are used to draw text on images within Orthanc. These fonts are
encoded as JSON files through the "./GenerateFont.py" script.

- UbuntuMonoBold-16.json is the Ubuntu Mono Bold, size 16, licensed
  under the Ubuntu Font Licence.
