/**
 * Orthanc - A Lightweight, RESTful DICOM Store
 * Copyright (C) 2012-2016 Sebastien Jodogne, Medical Physics
 * Department, University Hospital of Liege, Belgium
 * Copyright (C) 2017-2023 Osimis S.A., Belgium
 * Copyright (C) 2024-2026 Orthanc Team SRL, Belgium
 * Copyright (C) 2021-2026 Sebastien Jodogne, ICTEAM UCLouvain, Belgium
 *
 * This program is free software: you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation, either version 3 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program. If not, see
 * <http://www.gnu.org/licenses/>.
 **/


#include "../PrecompiledHeaders.h"
#include "StorageAccessor.h"

#include "../Logging.h"
#include "../StringMemoryBuffer.h"
#include "../Compression/ZlibCompressor.h"
#include "../MetricsRegistry.h"
#include "../OrthancException.h"
#include "../SerializationToolbox.h"
#include "../Toolbox.h"

#if ORTHANC_ENABLE_CIVETWEB == 1 || ORTHANC_ENABLE_MONGOOSE == 1
#  include "../HttpServer/HttpStreamTranscoder.h"
#endif

#include <boost/algorithm/string.hpp>
#include <boost/lexical_cast.hpp>


static const std::string METRICS_CREATE_DURATION = "orthanc_storage_create_duration_ms";
static const std::string METRICS_READ_DURATION = "orthanc_storage_read_duration_ms";
static const std::string METRICS_REMOVE_DURATION = "orthanc_storage_remove_duration_ms";
static const std::string METRICS_READ_BYTES = "orthanc_storage_read_bytes";
static const std::string METRICS_WRITTEN_BYTES = "orthanc_storage_written_bytes";


namespace Orthanc
{
  class StorageAccessor::MetricsTimer : public boost::noncopyable
  {
  private:
    std::unique_ptr<MetricsRegistry::Timer>  timer_;

  public:
    MetricsTimer(StorageAccessor& that,
                 const std::string& name)
    {
      if (that.metrics_ != NULL)
      {
        timer_.reset(new MetricsRegistry::Timer(*that.metrics_, name));
      }
    }
  };


  StorageAccessor::StorageAccessor(IPluginStorageArea& area) :
    area_(area),
    metrics_(NULL)
  {
  }
  

  StorageAccessor::StorageAccessor(IPluginStorageArea& area,
                                   MetricsRegistry& metrics) :
    area_(area),
    metrics_(&metrics)
  {
  }


  void StorageAccessor::Write(FileInfo& info,
                              const void* data,
                              size_t size,
                              FileContentType type,
                              CompressionType compression,
                              bool storeMd5,
                              const DicomInstanceToStore* instance)
  {
    std::string emptyMd5;
    Write(info, data, size, type, compression, emptyMd5, storeMd5, instance);
  }

  void StorageAccessor::Write(FileInfo& info,
                              const void* data,
                              size_t size,
                              FileContentType type,
                              CompressionType compression,
                              const std::string& precomputedMd5,
                              bool storeMd5,
                              const DicomInstanceToStore* instance)
  {
    const std::string uuid = Toolbox::GenerateUuid();

    std::string md5 = precomputedMd5;

    if (storeMd5 && md5.empty()) // if it has not been precomputed, compute it now
    {
      Toolbox::ComputeMD5(md5, data, size);
    }

    std::string customData;

    switch (compression)
    {
      case CompressionType_None:
      {
        {
          MetricsTimer timer(*this, METRICS_CREATE_DURATION);
          area_.Create(customData, uuid, data, size, type, compression, instance);
        }

        if (metrics_ != NULL)
        {
          metrics_->IncrementIntegerValue(METRICS_WRITTEN_BYTES, static_cast<int64_t>(size));
        }
        
        info = FileInfo(uuid, type, size, md5);
        info.SetCustomData(customData);
        return;
      }

      case CompressionType_ZlibWithSize:
      {
        ZlibCompressor zlib;

        std::string compressed;
        zlib.Compress(compressed, data, size);

        std::string compressedMD5;
      
        if (storeMd5)
        {
          Toolbox::ComputeMD5(compressedMD5, compressed);
        }

        {
          MetricsTimer timer(*this, METRICS_CREATE_DURATION);

          if (compressed.size() > 0)
          {
            area_.Create(customData, uuid, &compressed[0], compressed.size(), type, compression, instance);
          }
          else
          {
            area_.Create(customData, uuid, NULL, 0, type, compression, instance);
          }
        }

        if (metrics_ != NULL)
        {
          metrics_->IncrementIntegerValue(METRICS_WRITTEN_BYTES, static_cast<int64_t>(compressed.size()));
        }

        info = FileInfo(uuid, type, size, md5,
                        CompressionType_ZlibWithSize, compressed.size(), compressedMD5);
        info.SetCustomData(customData);
        return;
      }

      default:
        THROW_WITH_FILE_AND_LINE_INFO(ErrorCode_NotImplemented);
    }
  }


  void StorageAccessor::Read(std::string& content,
                             const FileInfo& info)
  {
    switch (info.GetCompressionType())
    {
      case CompressionType_None:
      {
        std::unique_ptr<IMemoryBuffer> buffer;

        {
          MetricsTimer timer(*this, METRICS_READ_DURATION);
          buffer.reset(area_.ReadRange(info.GetUuid(), info.GetContentType(), 0, info.GetCompressedSize(), info.GetCustomData()));
        }

        if (metrics_ != NULL)
        {
          metrics_->IncrementIntegerValue(METRICS_READ_BYTES, static_cast<int64_t>(buffer->GetSize()));
        }

        buffer->MoveToString(content);

        break;
      }

      case CompressionType_ZlibWithSize:
      {
        ZlibCompressor zlib;

        std::unique_ptr<IMemoryBuffer> compressed;
        
        {
          MetricsTimer timer(*this, METRICS_READ_DURATION);
          compressed.reset(area_.ReadRange(info.GetUuid(), info.GetContentType(), 0, info.GetCompressedSize(), info.GetCustomData()));
        }
        
        if (metrics_ != NULL)
        {
          metrics_->IncrementIntegerValue(METRICS_READ_BYTES, static_cast<int64_t>(compressed->GetSize()));
        }

        zlib.Uncompress(content, compressed->GetData(), compressed->GetSize());

        break;
      }

      default:
      {
        THROW_WITH_FILE_AND_LINE_INFO(ErrorCode_NotImplemented);
      }
    }

    // TODO Check the validity of the uncompressed MD5?
  }


  void StorageAccessor::ReadRaw(std::string& content,
                                const FileInfo& info)
  {
    std::unique_ptr<IMemoryBuffer> buffer;

    {
      MetricsTimer timer(*this, METRICS_READ_DURATION);
      buffer.reset(area_.ReadRange(info.GetUuid(), info.GetContentType(), 0, info.GetCompressedSize(), info.GetCustomData()));
    }

    if (metrics_ != NULL)
    {
      metrics_->IncrementIntegerValue(METRICS_READ_BYTES, static_cast<int64_t>(buffer->GetSize()));
    }

    buffer->MoveToString(content);
  }


  void StorageAccessor::Remove(const std::string& fileUuid,
                               FileContentType type,
                               const std::string& customData)
  {
    {
      MetricsTimer timer(*this, METRICS_REMOVE_DURATION);
      area_.Remove(fileUuid, type, customData);
    }
  }
  

  void StorageAccessor::Remove(const FileInfo &info)
  {
    Remove(info.GetUuid(), info.GetContentType(), info.GetCustomData());
  }


  void StorageAccessor::ReadStartRange(std::string& target,
                                       const FileInfo& info,
                                       uint64_t end /* exclusive */)
  {
    std::unique_ptr<IMemoryBuffer> buffer;

    {
      MetricsTimer timer(*this, METRICS_READ_DURATION);
      buffer.reset(area_.ReadRange(info.GetUuid(), info.GetContentType(), 0, end, info.GetCustomData()));
      assert(buffer->GetSize() == end);
    }

    if (metrics_ != NULL)
    {
      metrics_->IncrementIntegerValue(METRICS_READ_BYTES, static_cast<int64_t>(buffer->GetSize()));
    }

    buffer->MoveToString(target);
  }


  void StorageAccessor::ReadRange(std::string &target,
                                  const FileInfo &info,
                                  const StorageRange &range,
                                  bool uncompressIfNeeded)
  {
    if (uncompressIfNeeded &&
        info.GetCompressionType() != CompressionType_None)
    {
      // An uncompression is needed in this case
      std::string content;
      Read(content, info);
      range.Extract(target, content);
    }
    else
    {
      if (range.HasEnd() &&
          range.GetEndInclusive() >= info.GetCompressedSize())
      {
        throw OrthancException(ErrorCode_BadRange);
      }

      std::unique_ptr<IMemoryBuffer> buffer;

      if (range.HasStart() &&
          range.HasEnd())
      {
        buffer.reset(area_.ReadRange(info.GetUuid(), info.GetContentType(), range.GetStartInclusive(), range.GetEndInclusive() + 1, info.GetCustomData()));
      }
      else if (range.HasStart())
      {
        buffer.reset(area_.ReadRange(info.GetUuid(), info.GetContentType(), range.GetStartInclusive(), info.GetCompressedSize(), info.GetCustomData()));
      }
      else if (range.HasEnd())
      {
        buffer.reset(area_.ReadRange(info.GetUuid(), info.GetContentType(), 0, range.GetEndInclusive() + 1, info.GetCustomData()));
      }
      else
      {
        buffer.reset(area_.ReadRange(info.GetUuid(), info.GetContentType(), 0, info.GetCompressedSize(), info.GetCustomData()));
      }

      buffer->MoveToString(target);
    }
  }


#if ORTHANC_ENABLE_CIVETWEB == 1 || ORTHANC_ENABLE_MONGOOSE == 1
  void StorageAccessor::SetupSender(BufferHttpSender& sender,
                                    const FileInfo& info,
                                    const std::string& mime)
  {
    std::string tmp;
    Read(tmp, info);
    sender.SwapBuffer(tmp);

    sender.SetContentType(mime);

    const char* extension;
    switch (info.GetContentType())
    {
      case FileContentType_Dicom:
      case FileContentType_DicomUntilPixelData:
        extension = ".dcm";
        break;

      case FileContentType_DicomAsJson:
        extension = ".json";
        break;

      default:
        // Non-standard content type
        extension = "";
    }

    sender.SetContentFilename(info.GetUuid() + std::string(extension));
  }
#endif


#if ORTHANC_ENABLE_CIVETWEB == 1 || ORTHANC_ENABLE_MONGOOSE == 1
  void StorageAccessor::AnswerFile(HttpOutput& output,
                                   const FileInfo& info,
                                   MimeType mime,
                                   const std::string& contentFilename)
  {
    AnswerFile(output, info, EnumerationToString(mime), contentFilename);
  }
#endif


#if ORTHANC_ENABLE_CIVETWEB == 1 || ORTHANC_ENABLE_MONGOOSE == 1
  void StorageAccessor::AnswerFile(HttpOutput& output,
                                   const FileInfo& info,
                                   const std::string& mime,
                                   const std::string& contentFilename)
  {
    BufferHttpSender sender;
    SetupSender(sender, info, mime);
    sender.SetContentFilename(contentFilename);
  
    HttpStreamTranscoder transcoder(sender, CompressionType_None); // since 1.11.2, the storage accessor only returns uncompressed buffers
    output.Answer(transcoder);
  }
#endif


#if ORTHANC_ENABLE_CIVETWEB == 1 || ORTHANC_ENABLE_MONGOOSE == 1
  void StorageAccessor::AnswerFile(RestApiOutput& output,
                                   const FileInfo& info,
                                   MimeType mime,
                                   const std::string& contentFilename)
  {
    AnswerFile(output, info, EnumerationToString(mime), contentFilename);
  }
#endif


#if ORTHANC_ENABLE_CIVETWEB == 1 || ORTHANC_ENABLE_MONGOOSE == 1
  void StorageAccessor::AnswerFile(RestApiOutput& output,
                                   const FileInfo& info,
                                   const std::string& mime,
                                   const std::string& contentFilename)
  {
    BufferHttpSender sender;
    SetupSender(sender, info, mime);
    sender.SetContentFilename(contentFilename);

    HttpStreamTranscoder transcoder(sender, CompressionType_None); // since 1.11.2, the storage accessor only returns uncompressed buffers
    output.AnswerStream(transcoder);
  }
#endif

}
